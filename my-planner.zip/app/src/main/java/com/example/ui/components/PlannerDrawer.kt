package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlannerDestination
import com.example.ui.theme.DimOverlay
import com.example.ui.theme.GrayRoundedBg
import com.example.ui.theme.PlannerBlue
import com.example.ui.theme.PlannerBlueDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun PlannerThreeDContainer(
    isOpen: Boolean,
    currentDestination: PlannerDestination,
    onDestinationSelect: (PlannerDestination) -> Unit,
    onCloseDrawer: () -> Unit,
    onOpenDrawer: () -> Unit,
    onShareAppClick: () -> Unit,
    onPrivacyPolicyClick: () -> Unit,
    onRateAppClick: () -> Unit,
    isDarkMode: Boolean = false,
    onToggleTheme: () -> Unit = {},
    content: @Composable () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val drawerWidth = maxWidth * 0.8f
        val density = LocalDensity.current
        val drawerWidthPx = with(density) { drawerWidth.toPx() }

        // Smooth 3D animation progress
        val animProgress by animateFloatAsState(
            targetValue = if (isOpen) 1f else 0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "drawer3DProgress"
        )

        // 1. Main Planner Screen (3D Animated in Perspective behind Drawer)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // 3D Perspective rotation & scaling
                    scaleX = 1f - (0.12f * animProgress)
                    scaleY = 1f - (0.12f * animProgress)
                    rotationY = -10f * animProgress
                    translationX = (drawerWidthPx * 0.35f) * animProgress
                    cameraDistance = 14 * density.density
                    shape = RoundedCornerShape((24 * animProgress).dp)
                    clip = animProgress > 0.01f
                }
                .shadow(
                    elevation = if (animProgress > 0.01f) 16.dp else 0.dp,
                    shape = RoundedCornerShape((24 * animProgress).dp)
                )
        ) {
            content()

            // Dimmed Gray Overlay behind Drawer
            if (animProgress > 0.01f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DimOverlay.copy(alpha = 0.55f * animProgress))
                        .clickable(enabled = isOpen) {
                            onCloseDrawer()
                        }
                )
            }
        }

        // 2. Left-Side Navigation Drawer (80% of screen width)
        val drawerOffsetXPx = (-drawerWidthPx * (1f - animProgress)).roundToInt()

        if (animProgress > 0.001f || isOpen) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(drawerWidth)
                    .offset { IntOffset(x = drawerOffsetXPx, y = 0) }
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                        spotColor = Color(0x66000000)
                    )
                    .clip(RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp))
                    .background(Color.White)
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { _, dragAmount ->
                            if (dragAmount < -20) {
                                onCloseDrawer()
                            }
                        }
                    }
                    .testTag("planner_drawer")
            ) {
                PlannerDrawerContent(
                    currentDestination = currentDestination,
                    onDestinationSelect = onDestinationSelect,
                    onShareAppClick = onShareAppClick,
                    onPrivacyPolicyClick = onPrivacyPolicyClick,
                    onRateAppClick = onRateAppClick,
                    isDarkMode = isDarkMode,
                    onToggleTheme = onToggleTheme
                )
            }
        }
    }
}

@Composable
fun PlannerDrawerContent(
    currentDestination: PlannerDestination,
    onDestinationSelect: (PlannerDestination) -> Unit,
    onShareAppClick: () -> Unit,
    onPrivacyPolicyClick: () -> Unit,
    onRateAppClick: () -> Unit,
    isDarkMode: Boolean = false,
    onToggleTheme: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Large Blue Header: "My Planner"
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(PlannerBlue, PlannerBlueDark)
                    )
                )
                .statusBarsPadding()
                .padding(horizontal = 24.dp, vertical = 28.dp)
                .testTag("drawer_header")
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                            .border(1.5.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_app_logo),
                            contentDescription = "My Planner Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }

                    Column {
                        Text(
                            text = "My Planner",
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "All-in-One Daily Organizer",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            }
        }

        // Scrollable Drawer Menu Items
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Section 1: Major Planner Features
            PlannerDestination.entries.forEach { destination ->
                val isSelected = currentDestination == destination

                DrawerMenuItem(
                    emoji = destination.iconEmoji,
                    title = destination.title,
                    isLightGrayBg = destination.isLightGrayBg,
                    isSelected = isSelected,
                    onClick = { onDestinationSelect(destination) }
                )
            }

            // Horizontal Divider separating major features from Share, Privacy, Rate, Theme
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 10.dp),
                thickness = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            )

            // Section 2: Secondary Options
            // Share App
            SecondaryDrawerItem(
                emoji = "🔗",
                title = "Share App",
                testTag = "drawer_item_share",
                onClick = onShareAppClick
            )

            // Privacy Policy
            SecondaryDrawerItem(
                emoji = "🔒",
                title = "Privacy Policy",
                testTag = "drawer_item_privacy",
                onClick = onPrivacyPolicyClick
            )

            // Rate App
            SecondaryDrawerItem(
                emoji = "⭐",
                title = "Rate App",
                testTag = "drawer_item_rate",
                onClick = onRateAppClick
            )

            // Theme Toggle Option
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .clickable { onToggleTheme() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("drawer_theme_toggle"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isDarkMode) "🌙" else "☀️",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(end = 14.dp)
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isDarkMode) "Dark Mode" else "Light Mode",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isDarkMode) "Tap to switch to Light" else "Tap to switch to Dark",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Switch(
                    checked = isDarkMode,
                    onCheckedChange = { onToggleTheme() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PlannerBlue
                    )
                )
            }

            Spacer(modifier = Modifier.weight(1f, fill = false))
            Spacer(modifier = Modifier.height(24.dp))

            // App Footer Note
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "My Planner v1.0 • 100% Offline & Private",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
fun DrawerMenuItem(
    emoji: String,
    title: String,
    isLightGrayBg: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val defaultBg = if (isLightGrayBg) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
    val targetBg = if (isSelected) PlannerBlue.copy(alpha = 0.16f) else defaultBg
    val animatedBg by animateColorAsState(targetValue = targetBg, label = "drawerItemBg")

    val shape = RoundedCornerShape(12.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(animatedBg)
            .border(
                width = if (isSelected) 1.5.dp else if (!isLightGrayBg) 1.dp else 0.dp,
                color = if (isSelected) PlannerBlue else if (!isLightGrayBg) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f) else Color.Transparent,
                shape = shape
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag("drawer_item_${title.lowercase().replace(" ", "_")}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = emoji,
            fontSize = 22.sp,
            modifier = Modifier.padding(end = 14.dp)
        )

        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) PlannerBlue else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )

        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(PlannerBlue)
            )
        }
    }
}

@Composable
fun SecondaryDrawerItem(
    emoji: String,
    title: String,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = emoji,
            fontSize = 20.sp,
            modifier = Modifier.padding(end = 14.dp)
        )

        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(18.dp)
        )
    }
}
