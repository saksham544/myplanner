package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BudgetItem
import com.example.data.ReminderItem
import com.example.data.ShoppingItem
import com.example.data.TodoTask
import com.example.ui.PlannerDestination
import com.example.ui.components.ThreeDCard
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.PlannerBlue
import com.example.ui.theme.PlannerBlueDark
import java.util.Locale

@Composable
fun SummaryScreen(
    shoppingItems: List<ShoppingItem>,
    todoTasks: List<TodoTask>,
    reminders: List<ReminderItem>,
    budgetItems: List<BudgetItem>,
    onNavigateTo: (PlannerDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalTasks = todoTasks.size
    val completedTasks = todoTasks.count { it.isCompleted }
    val taskRate = if (totalTasks > 0) completedTasks.toFloat() / totalTasks.toFloat() else 0.5f

    val totalShopping = shoppingItems.size
    val boughtShopping = shoppingItems.count { it.isBought }
    val shoppingRate = if (totalShopping > 0) boughtShopping.toFloat() / totalShopping.toFloat() else 0.5f

    val totalIncome = budgetItems.filter { it.type == "INCOME" }.sumOf { it.amount }
    val totalExpense = budgetItems.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val netBalance = totalIncome - totalExpense
    val activeRemindersCount = reminders.count { it.isActive }

    // Overall Planner Completion Score
    val overallScore = (((taskRate * 0.5f) + (shoppingRate * 0.5f)) * 100).toInt().coerceIn(10, 100)

    var startAnimation by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        startAnimation = 1f
    }
    val animatedScoreArc by animateFloatAsState(
        targetValue = if (startAnimation > 0f) (overallScore / 100f) * 360f else 0f,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "scoreArc"
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero 3D Planner Health Meter
        item {
            ThreeDCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("summary_hero_card"),
                shape = RoundedCornerShape(22.dp),
                elevation = 6.dp,
                enableTilt = true
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(PlannerBlue, PlannerBlueDark)
                            )
                        )
                        .padding(22.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("ℹ️ Planner Dashboard", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                "Organization Score",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                if (overallScore >= 70) "Excellent! You're on top of your schedule."
                                else "Keep going! Check off tasks & shopping to boost score.",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // 3D Circular Progress Arc
                        Box(
                            modifier = Modifier.size(96.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.size(90.dp)) {
                                // Background circle
                                drawArc(
                                    color = Color.White.copy(alpha = 0.2f),
                                    startAngle = -90f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                                )
                                // Active arc
                                drawArc(
                                    brush = Brush.sweepGradient(
                                        colors = listOf(Color(0xFF69F0AE), Color(0xFF40C4FF), Color(0xFF69F0AE))
                                    ),
                                    startAngle = -90f,
                                    sweepAngle = animatedScoreArc,
                                    useCenter = false,
                                    style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "$overallScore%",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                                Text(
                                    "done",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section Title: Quick Modules
        item {
            Text(
                "Planner Modules",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // 2x2 Grid of 3D Cards for Modules
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Row 1: Shopping & To-Do
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Shopping Card
                    ModuleSummaryCard(
                        modifier = Modifier.weight(1f),
                        emoji = "🛒",
                        title = "Shopping List",
                        statusText = "$boughtShopping of $totalShopping bought",
                        fraction = shoppingRate,
                        accentColor = PlannerBlue,
                        onClick = { onNavigateTo(PlannerDestination.SHOPPING_LIST) }
                    )

                    // To-Do Card
                    ModuleSummaryCard(
                        modifier = Modifier.weight(1f),
                        emoji = "☑️",
                        title = "To-Do List",
                        statusText = "$completedTasks of $totalTasks done",
                        fraction = taskRate,
                        accentColor = AccentGreen,
                        onClick = { onNavigateTo(PlannerDestination.TODO_LIST) }
                    )
                }

                // Row 2: Reminders & Budget
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Reminders Card
                    ModuleSummaryCard(
                        modifier = Modifier.weight(1f),
                        emoji = "🔔",
                        title = "Reminders",
                        statusText = "$activeRemindersCount active alerts",
                        fraction = if (reminders.isNotEmpty()) activeRemindersCount.toFloat() / reminders.size.toFloat() else 0f,
                        accentColor = AccentOrange,
                        onClick = { onNavigateTo(PlannerDestination.REMINDERS) }
                    )

                    // Budget Card
                    ModuleSummaryCard(
                        modifier = Modifier.weight(1f),
                        emoji = "💰",
                        title = "Budget",
                        statusText = String.format(Locale.US, "Balance $%,.0f", netBalance),
                        fraction = if (totalIncome > 0) ((totalIncome - totalExpense) / totalIncome).toFloat().coerceIn(0f, 1f) else 0f,
                        accentColor = AccentTeal,
                        onClick = { onNavigateTo(PlannerDestination.BUDGET) }
                    )
                }
            }
        }

        // Data Visualization: Financial Overview Bar
        item {
            ThreeDCard(
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color.White,
                elevation = 3.dp,
                onClick = { onNavigateTo(PlannerDestination.BUDGET) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📊", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Cash Flow Visualization",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Go to budget",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val totalFlow = (totalIncome + totalExpense).coerceAtLeast(1.0)
                    val incomeFrac = (totalIncome / totalFlow).toFloat().coerceIn(0.05f, 0.95f)
                    val expenseFrac = (totalExpense / totalFlow).toFloat().coerceIn(0.05f, 0.95f)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(RoundedCornerShape(7.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(incomeFrac)
                                .height(14.dp)
                                .background(AccentGreen)
                        )
                        Box(
                            modifier = Modifier
                                .weight(expenseFrac)
                                .height(14.dp)
                                .background(AccentRed)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(AccentGreen))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                String.format(Locale.US, "Income: $%,.2f", totalIncome),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(AccentRed))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                String.format(Locale.US, "Expenses: $%,.2f", totalExpense),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Priority Items Quick Peek
        item {
            ThreeDCard(
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color.White,
                elevation = 3.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Pending Priorities",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val pendingTasks = todoTasks.filter { !it.isCompleted }.take(2)
                    val pendingShopping = shoppingItems.filter { !it.isBought }.take(2)
                    val activeRemindersList = reminders.filter { it.isActive }.take(2)

                    if (pendingTasks.isEmpty() && pendingShopping.isEmpty() && activeRemindersList.isEmpty()) {
                        Text(
                            "🎉 All caught up! No pending tasks, shopping, or reminders.",
                            fontSize = 13.sp,
                            color = AccentGreen,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        pendingTasks.forEach { task ->
                            PriorityRow(emoji = "☑️", title = task.title, badge = "${task.priority} Priority", badgeColor = AccentOrange)
                        }
                        pendingShopping.forEach { item ->
                            PriorityRow(emoji = "🛒", title = "${item.title} (${item.quantity})", badge = "Need to buy", badgeColor = PlannerBlue)
                        }
                        activeRemindersList.forEach { reminder ->
                            PriorityRow(emoji = "🔔", title = reminder.title, badge = reminder.dateTimeStr, badgeColor = AccentPurple)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModuleSummaryCard(
    modifier: Modifier = Modifier,
    emoji: String,
    title: String,
    statusText: String,
    fraction: Float,
    accentColor: Color,
    onClick: () -> Unit
) {
    val animatedFraction by animateFloatAsState(targetValue = fraction, label = "moduleFrac")

    ThreeDCard(
        modifier = modifier.testTag("summary_${title.lowercase().replace(" ", "_")}"),
        containerColor = Color.White,
        elevation = 3.dp,
        onClick = onClick,
        enableTilt = true
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 24.sp)
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open $title",
                    tint = Color.LightGray,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            Text(
                statusText,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp),
                maxLines = 1
            )

            LinearProgressIndicator(
                progress = { animatedFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = accentColor,
                trackColor = Color(0xFFEEEEEE)
            )
        }
    }
}

@Composable
fun PriorityRow(
    emoji: String,
    title: String,
    badge: String,
    badgeColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 16.sp)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
            maxLines = 1
        )
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(badgeColor.copy(alpha = 0.12f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                badge,
                fontSize = 10.sp,
                color = badgeColor,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
