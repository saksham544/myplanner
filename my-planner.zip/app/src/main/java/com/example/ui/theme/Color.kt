package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Blue Palette
val PlannerBlue = Color(0xFF1565C0)
val PlannerBlueDark = Color(0xFF0D47A1)
val PlannerBlueLight = Color(0xFF1976D2)
val PlannerBlueContainer = Color(0xFFE3F2FD)
val PlannerOnBlueContainer = Color(0xFF0D47A1)

// Accent & Category Colors
val AccentTeal = Color(0xFF00897B)
val AccentOrange = Color(0xFFF57C00)
val AccentRed = Color(0xFFE53935)
val AccentGreen = Color(0xFF43A047)
val AccentPurple = Color(0xFF7B1FA2)

// Neutrals & Surface Colors
val GrayRoundedBg = Color(0xFFF1F3F5)
val GrayBorder = Color(0xFFE0E0E0)
val TextPrimary = Color(0xFF212121)
val TextSecondary = Color(0xFF757575)
val CardSurface = Color(0xFFFFFFFF)
val DimOverlay = Color(0x66000000)

// Dark Palette
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2C2C2C)
val PlannerBlueDarkTheme = Color(0xFF90CAF9)
