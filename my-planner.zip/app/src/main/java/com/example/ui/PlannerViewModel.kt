package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BudgetItem
import com.example.data.PlannerDatabase
import com.example.data.PlannerRepository
import com.example.data.ReminderItem
import com.example.data.ShoppingItem
import com.example.data.TodoTask
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class PlannerDestination(
    val title: String,
    val iconEmoji: String,
    val isLightGrayBg: Boolean
) {
    SHOPPING_LIST("Shopping List", "🛒", true),
    TODO_LIST("To-Do List", "☑️", true),
    REMINDERS("Reminders", "🔔", true),
    BUDGET("Budget", "💰", false),
    SUMMARY("Summary", "ℹ️", false)
}

class PlannerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PlannerRepository

    init {
        val db = PlannerDatabase.getDatabase(application, viewModelScope)
        repository = PlannerRepository(db.plannerDao())
    }

    // Theme State
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Search State
    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Navigation State
    private val _currentDestination = MutableStateFlow(PlannerDestination.SHOPPING_LIST)
    val currentDestination: StateFlow<PlannerDestination> = _currentDestination.asStateFlow()

    private val _isDrawerOpen = MutableStateFlow(false)
    val isDrawerOpen: StateFlow<Boolean> = _isDrawerOpen.asStateFlow()

    // Dialog States
    private val _showPrivacyDialog = MutableStateFlow(false)
    val showPrivacyDialog: StateFlow<Boolean> = _showPrivacyDialog.asStateFlow()

    private val _showRateDialog = MutableStateFlow(false)
    val showRateDialog: StateFlow<Boolean> = _showRateDialog.asStateFlow()

    private val _userRating = MutableStateFlow(5)
    val userRating: StateFlow<Int> = _userRating.asStateFlow()

    // Data Flows
    val shoppingItems: StateFlow<List<ShoppingItem>> = repository.shoppingItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todoTasks: StateFlow<List<TodoTask>> = repository.todoTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderItem>> = repository.reminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgetItems: StateFlow<List<BudgetItem>> = repository.budgetItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Theme actions
    fun toggleTheme() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
    }

    // Search actions
    fun setSearchActive(active: Boolean) {
        _isSearchActive.value = active
        if (!active) {
            _searchQuery.value = ""
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearSearch() {
        _searchQuery.value = ""
    }

    // Navigation actions
    fun selectDestination(destination: PlannerDestination) {
        _currentDestination.value = destination
        _isDrawerOpen.value = false
    }

    fun openDrawer() {
        _isDrawerOpen.value = true
    }

    fun closeDrawer() {
        _isDrawerOpen.value = false
    }

    fun toggleDrawer() {
        _isDrawerOpen.value = !_isDrawerOpen.value
    }

    fun setPrivacyDialogVisible(visible: Boolean) {
        _showPrivacyDialog.value = visible
        if (visible) _isDrawerOpen.value = false
    }

    fun setRateDialogVisible(visible: Boolean) {
        _showRateDialog.value = visible
        if (visible) _isDrawerOpen.value = false
    }

    fun setRating(rating: Int) {
        _userRating.value = rating
    }

    // Shopping actions
    fun addShoppingItem(title: String, quantity: String, category: String) {
        viewModelScope.launch {
            repository.insertShoppingItem(
                ShoppingItem(
                    title = title.trim(),
                    quantity = if (quantity.isBlank()) "1" else quantity.trim(),
                    category = category
                )
            )
        }
    }

    fun toggleShoppingItemBought(item: ShoppingItem) {
        viewModelScope.launch {
            repository.updateShoppingItem(item.copy(isBought = !item.isBought))
        }
    }

    fun deleteShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.deleteShoppingItem(item)
        }
    }

    fun clearBoughtShoppingItems() {
        viewModelScope.launch {
            repository.clearBoughtShoppingItems()
        }
    }

    // Todo actions
    fun addTodoTask(title: String, priority: String, category: String, dueDate: String) {
        viewModelScope.launch {
            repository.insertTodoTask(
                TodoTask(
                    title = title.trim(),
                    priority = priority,
                    category = category,
                    dueDate = if (dueDate.isBlank()) "Today" else dueDate.trim()
                )
            )
        }
    }

    fun toggleTodoTaskCompleted(task: TodoTask) {
        viewModelScope.launch {
            repository.updateTodoTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTodoTask(task: TodoTask) {
        viewModelScope.launch {
            repository.deleteTodoTask(task)
        }
    }

    fun clearCompletedTasks() {
        viewModelScope.launch {
            repository.clearCompletedTasks()
        }
    }

    // Reminder actions
    fun addReminder(title: String, dateTimeStr: String, tag: String) {
        viewModelScope.launch {
            repository.insertReminder(
                ReminderItem(
                    title = title.trim(),
                    dateTimeStr = dateTimeStr.trim(),
                    tag = tag
                )
            )
        }
    }

    fun toggleReminderActive(reminder: ReminderItem) {
        viewModelScope.launch {
            repository.updateReminder(reminder.copy(isActive = !reminder.isActive))
        }
    }

    fun deleteReminder(reminder: ReminderItem) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
        }
    }

    // Budget actions
    fun addBudgetItem(title: String, amount: Double, type: String, category: String, dateStr: String) {
        viewModelScope.launch {
            repository.insertBudgetItem(
                BudgetItem(
                    title = title.trim(),
                    amount = amount,
                    type = type,
                    category = category,
                    dateStr = if (dateStr.isBlank()) "Today" else dateStr.trim()
                )
            )
        }
    }

    fun deleteBudgetItem(item: BudgetItem) {
        viewModelScope.launch {
            repository.deleteBudgetItem(item)
        }
    }
}
