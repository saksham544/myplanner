package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.PlannerBlue

/**
 * Predefined and styled categories/labels for Tasks and Shopping Items
 */
object CategoryStyleHelper {
    data class CategoryVisual(
        val name: String,
        val icon: String,
        val color: Color
    )

    val TaskCategories = listOf(
        CategoryVisual("Work", "💼", PlannerBlue),
        CategoryVisual("Home", "🏡", AccentOrange),
        CategoryVisual("Personal", "👤", AccentTeal),
        CategoryVisual("Health", "💪", AccentGreen),
        CategoryVisual("Urgent", "🔥", AccentRed),
        CategoryVisual("Study", "📚", AccentPurple)
    )

    val ShoppingCategories = listOf(
        CategoryVisual("Groceries", "🥦", AccentGreen),
        CategoryVisual("Household", "🏠", AccentOrange),
        CategoryVisual("Home", "🛋️", AccentTeal),
        CategoryVisual("Personal", "🧴", AccentPurple),
        CategoryVisual("Electronics", "🔌", PlannerBlue),
        CategoryVisual("Snacks", "🍿", Color(0xFFE91E63))
    )

    fun getCategoryVisual(name: String, isShopping: Boolean = false): CategoryVisual {
        val list = if (isShopping) ShoppingCategories else TaskCategories
        val found = list.firstOrNull { it.name.equals(name.trim(), ignoreCase = true) }
        if (found != null) return found

        // Generate consistent hash-based color for custom user categories
        val fallbackColors = listOf(
            PlannerBlue,
            AccentTeal,
            AccentOrange,
            AccentGreen,
            AccentPurple,
            AccentRed,
            Color(0xFF0097A7),
            Color(0xFFE91E63)
        )
        val colorIndex = Math.abs(name.hashCode()) % fallbackColors.size
        return CategoryVisual(name, "🏷️", fallbackColors[colorIndex])
    }
}

@Composable
fun CategoryBadge(
    category: String,
    modifier: Modifier = Modifier,
    isShopping: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val visual = CategoryStyleHelper.getCategoryVisual(category, isShopping)
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    val badgeModifier = if (onClick != null) {
        modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .background(if (isDark) visual.color.copy(alpha = 0.22f) else visual.color.copy(alpha = 0.12f))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    } else {
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isDark) visual.color.copy(alpha = 0.22f) else visual.color.copy(alpha = 0.12f))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    }

    Row(
        modifier = badgeModifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = visual.icon,
            fontSize = 11.sp,
            modifier = Modifier.padding(end = 4.dp)
        )
        Text(
            text = category,
            fontSize = 11.sp,
            color = if (isDark) visual.color.copy(alpha = 0.95f) else visual.color,
            fontWeight = FontWeight.SemiBold
        )
    }
}
