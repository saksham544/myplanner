package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.AccentRed
import com.example.ui.theme.PlannerBlue

@Composable
fun AddShoppingDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, quantity: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var category by remember { mutableStateOf("Groceries") }
    var isCustomLabel by remember { mutableStateOf(false) }
    var customLabelText by remember { mutableStateOf("") }
    val categories = listOf("Groceries", "Household", "Home", "Personal", "Electronics", "Snacks")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🛒", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                Text("Add Shopping Item", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Item Name") },
                    placeholder = { Text("e.g., Almond Milk, Bread...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("shopping_title_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("Quantity / Pack") },
                    placeholder = { Text("e.g., 2 bottles, 500g") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("shopping_qty_input"),
                    singleLine = true
                )

                Text("Category / Label", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = !isCustomLabel && category == cat,
                            onClick = {
                                isCustomLabel = false
                                category = cat
                            },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = !isCustomLabel && category == cat,
                            onClick = {
                                isCustomLabel = false
                                category = cat
                            },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                    FilterChip(
                        selected = isCustomLabel,
                        onClick = { isCustomLabel = true },
                        label = { Text("+ Custom", fontSize = 12.sp) }
                    )
                }

                if (isCustomLabel) {
                    OutlinedTextField(
                        value = customLabelText,
                        onValueChange = { customLabelText = it },
                        label = { Text("Custom Label Name") },
                        placeholder = { Text("e.g., Pantry, Office, Party") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shopping_custom_label_input"),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            val resolvedCategory = if (isCustomLabel && customLabelText.isNotBlank()) customLabelText.trim() else category
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, quantity, resolvedCategory)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue),
                modifier = Modifier.testTag("shopping_confirm_button")
            ) {
                Text("Add to List")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddTodoDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, priority: String, category: String, dueDate: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Medium") }
    var category by remember { mutableStateOf("Work") }
    var isCustomLabel by remember { mutableStateOf(false) }
    var customLabelText by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("Today") }

    val priorities = listOf("High", "Medium", "Low")
    val categories = listOf("Work", "Home", "Personal", "Health", "Urgent")
    val dateOptions = listOf("Today", "Tomorrow", "This Weekend", "Next Week")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("☑️", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                Text("Create Task", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Description") },
                    placeholder = { Text("What needs to get done?") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("todo_title_input"),
                    singleLine = true
                )

                Text("Priority Level", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    priorities.forEach { prio ->
                        val chipColor = when (prio) {
                            "High" -> AccentRed
                            "Medium" -> AccentOrange
                            else -> AccentGreen
                        }
                        FilterChip(
                            selected = priority == prio,
                            onClick = { priority = prio },
                            label = { Text(prio) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = chipColor.copy(alpha = 0.2f),
                                selectedLabelColor = chipColor
                            )
                        )
                    }
                }

                Text("Category / Label", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = !isCustomLabel && category == cat,
                            onClick = {
                                isCustomLabel = false
                                category = cat
                            },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = !isCustomLabel && category == cat,
                            onClick = {
                                isCustomLabel = false
                                category = cat
                            },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                    FilterChip(
                        selected = isCustomLabel,
                        onClick = { isCustomLabel = true },
                        label = { Text("+ Custom", fontSize = 12.sp) }
                    )
                }

                if (isCustomLabel) {
                    OutlinedTextField(
                        value = customLabelText,
                        onValueChange = { customLabelText = it },
                        label = { Text("Custom Label Name") },
                        placeholder = { Text("e.g., Project A, Finance, Errand") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("todo_custom_label_input"),
                        singleLine = true
                    )
                }

                Text("Due", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    dateOptions.take(2).forEach { date ->
                        FilterChip(
                            selected = dueDate == date,
                            onClick = { dueDate = date },
                            label = { Text(date, fontSize = 12.sp) }
                        )
                    }
                    dateOptions.drop(2).take(1).forEach { date ->
                        FilterChip(
                            selected = dueDate == date,
                            onClick = { dueDate = date },
                            label = { Text(date, fontSize = 12.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            val resolvedCategory = if (isCustomLabel && customLabelText.isNotBlank()) customLabelText.trim() else category
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, priority, resolvedCategory, dueDate)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue),
                modifier = Modifier.testTag("todo_confirm_button")
            ) {
                Text("Save Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddReminderDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, dateTimeStr: String, tag: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var timeOption by remember { mutableStateOf("Today at 3:00 PM") }
    var tag by remember { mutableStateOf("Meeting") }

    val presetTimes = listOf(
        "In 1 hour",
        "Today at 3:00 PM",
        "Today at 6:00 PM",
        "Tomorrow at 9:00 AM"
    )
    val tags = listOf("Meeting", "Personal", "Health", "Bills")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔔", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                Text("Set Reminder", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Reminder Title") },
                    placeholder = { Text("e.g., Call doctor, Team sync...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reminder_title_input"),
                    singleLine = true
                )

                Text("Scheduled Time", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    presetTimes.forEach { time ->
                        FilterChip(
                            selected = timeOption == time,
                            onClick = { timeOption = time },
                            label = { Text(time) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Text("Tag", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tags.forEach { t ->
                        FilterChip(
                            selected = tag == t,
                            onClick = { tag = t },
                            label = { Text(t, fontSize = 12.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, timeOption, tag)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue),
                modifier = Modifier.testTag("reminder_confirm_button")
            ) {
                Text("Set Reminder")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddBudgetDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, amount: Double, type: String, category: String, dateStr: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("EXPENSE") }
    var category by remember { mutableStateOf("Food & Dining") }

    val expenseCategories = listOf("Food & Dining", "Bills & Utilities", "Shopping", "Transport", "Entertainment", "Other")
    val incomeCategories = listOf("Salary", "Freelance", "Investment", "Gift", "Other")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("💰", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                Text("Add Transaction", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = {
                            type = "EXPENSE"
                            category = "Food & Dining"
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (type == "EXPENSE") AccentRed else Color.Transparent,
                            contentColor = if (type == "EXPENSE") Color.White else MaterialTheme.colorScheme.onSurface
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Expense", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            type = "INCOME"
                            category = "Salary"
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (type == "INCOME") AccentGreen else Color.Transparent,
                            contentColor = if (type == "INCOME") Color.White else MaterialTheme.colorScheme.onSurface
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Income", fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Description") },
                    placeholder = { Text(if (type == "EXPENSE") "e.g., Grocery run, Lunch" else "e.g., Client payout, Salary") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("budget_title_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount ($)") },
                    placeholder = { Text("0.00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("budget_amount_input"),
                    singleLine = true
                )

                Text("Category", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                val currentCats = if (type == "EXPENSE") expenseCategories else incomeCategories
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    currentCats.take(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    currentCats.drop(3).take(3).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && amount > 0) {
                        onConfirm(title, amount, type, category, "Today")
                    }
                },
                enabled = title.isNotBlank() && (amountStr.toDoubleOrNull() ?: 0.0) > 0,
                colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue),
                modifier = Modifier.testTag("budget_confirm_button")
            ) {
                Text("Add Entry")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PlannerBlue.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Privacy Icon",
                        tint = PlannerBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text("Privacy Policy", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Your privacy is our utmost priority.",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = PlannerBlue
                )
                Text(
                    "• 100% On-Device Storage: All your shopping lists, to-do tasks, reminders, and budget records are stored locally in your device's private SQLite database.\n\n" +
                    "• Zero Data Collection: We do not collect, track, share, or transmit your personal entries to external servers or third parties.\n\n" +
                    "• Offline Capable: My Planner works completely offline without requiring continuous network access or accounts.\n\n" +
                    "• User Control: You have complete sovereignty over your data and can add, edit, or delete any record instantly.",
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue)
            ) {
                Text("Understood")
            }
        }
    )
}

@Composable
fun RateAppDialog(
    initialRating: Int,
    onDismiss: () -> Unit,
    onSubmit: (rating: Int) -> Unit
) {
    var rating by remember { mutableIntStateOf(initialRating) }
    var feedbackText by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⭐", fontSize = 24.sp, modifier = Modifier.padding(end = 8.dp))
                Text("Rate My Planner", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!submitted) {
                    Text(
                        "How is your experience organizing your day?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Interactive 5 stars
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        for (i in 1..5) {
                            val isSelected = i <= rating
                            val scale by animateFloatAsState(
                                targetValue = if (isSelected) 1.2f else 1f,
                                label = "starScale"
                            )
                            Icon(
                                imageVector = if (isSelected) Icons.Filled.Star else Icons.Outlined.Star,
                                contentDescription = "$i Stars",
                                tint = if (isSelected) Color(0xFFFFB300) else Color(0xFFBDBDBD),
                                modifier = Modifier
                                    .size(38.dp)
                                    .scale(scale)
                                    .padding(2.dp)
                                    .clickable { rating = i }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        label = { Text("What do you like or want improved? (optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🎉", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Thank you for rating $rating Stars!",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = PlannerBlue
                            )
                            Text(
                                "Your review helps make My Planner better every day.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!submitted) {
                Button(
                    onClick = {
                        submitted = true
                        onSubmit(rating)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue)
                ) {
                    Text("Submit Rating")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = PlannerBlue)
                ) {
                    Text("Done")
                }
            }
        },
        dismissButton = {
            if (!submitted) {
                TextButton(onClick = onDismiss) {
                    Text("Later")
                }
            }
        }
    )
}
