package com.example.data

import kotlinx.coroutines.flow.Flow

class PlannerRepository(private val dao: PlannerDao) {
    // Shopping
    val shoppingItems: Flow<List<ShoppingItem>> = dao.getAllShoppingItems()
    suspend fun insertShoppingItem(item: ShoppingItem) = dao.insertShoppingItem(item)
    suspend fun updateShoppingItem(item: ShoppingItem) = dao.updateShoppingItem(item)
    suspend fun deleteShoppingItem(item: ShoppingItem) = dao.deleteShoppingItem(item)
    suspend fun clearBoughtShoppingItems() = dao.clearBoughtShoppingItems()

    // Tasks
    val todoTasks: Flow<List<TodoTask>> = dao.getAllTodoTasks()
    suspend fun insertTodoTask(task: TodoTask) = dao.insertTodoTask(task)
    suspend fun updateTodoTask(task: TodoTask) = dao.updateTodoTask(task)
    suspend fun deleteTodoTask(task: TodoTask) = dao.deleteTodoTask(task)
    suspend fun clearCompletedTasks() = dao.clearCompletedTasks()

    // Reminders
    val reminders: Flow<List<ReminderItem>> = dao.getAllReminders()
    suspend fun insertReminder(reminder: ReminderItem) = dao.insertReminder(reminder)
    suspend fun updateReminder(reminder: ReminderItem) = dao.updateReminder(reminder)
    suspend fun deleteReminder(reminder: ReminderItem) = dao.deleteReminder(reminder)

    // Budget
    val budgetItems: Flow<List<BudgetItem>> = dao.getAllBudgetItems()
    suspend fun insertBudgetItem(item: BudgetItem) = dao.insertBudgetItem(item)
    suspend fun updateBudgetItem(item: BudgetItem) = dao.updateBudgetItem(item)
    suspend fun deleteBudgetItem(item: BudgetItem) = dao.deleteBudgetItem(item)
}
