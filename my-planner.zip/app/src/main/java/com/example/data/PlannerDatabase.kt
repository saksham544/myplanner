package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ShoppingItem::class,
        TodoTask::class,
        ReminderItem::class,
        BudgetItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PlannerDatabase : RoomDatabase() {
    abstract fun plannerDao(): PlannerDao

    companion object {
        @Volatile
        private var INSTANCE: PlannerDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): PlannerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PlannerDatabase::class.java,
                    "planner_database"
                )
                .addCallback(PlannerDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class PlannerDatabaseCallback(
            private val scope: CoroutineScope
        ) : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.plannerDao())
                    }
                }
            }

            suspend fun populateInitialData(dao: PlannerDao) {
                // Initial Shopping Items
                dao.insertShoppingItem(ShoppingItem(title = "Organic Whole Milk", quantity = "2 cartons", category = "Groceries", isBought = false))
                dao.insertShoppingItem(ShoppingItem(title = "Fresh Avocados & Sourdough", quantity = "4 pcs", category = "Groceries", isBought = true))
                dao.insertShoppingItem(ShoppingItem(title = "Kitchen Paper Towels", quantity = "1 pack", category = "Household", isBought = false))
                dao.insertShoppingItem(ShoppingItem(title = "USB-C Fast Charging Cable", quantity = "1 pc", category = "Electronics", isBought = false))

                // Initial To-Do Tasks
                dao.insertTodoTask(TodoTask(title = "Finalize quarterly budget report", priority = "High", category = "Work", dueDate = "Today", isCompleted = false))
                dao.insertTodoTask(TodoTask(title = "Pick up prescription from pharmacy", priority = "Medium", category = "Personal", dueDate = "Today", isCompleted = true))
                dao.insertTodoTask(TodoTask(title = "Schedule dentist checkup appointment", priority = "Low", category = "Health", dueDate = "Tomorrow", isCompleted = false))
                dao.insertTodoTask(TodoTask(title = "Prepare presentation slides for Monday team sync", priority = "High", category = "Work", dueDate = "Next Monday", isCompleted = false))

                // Initial Reminders
                dao.insertReminder(ReminderItem(title = "Team Standup Meeting", dateTimeStr = "Today at 2:00 PM", tag = "Meeting", isActive = true))
                dao.insertReminder(ReminderItem(title = "Water indoor houseplants", dateTimeStr = "Today at 6:30 PM", tag = "Personal", isActive = true))
                dao.insertReminder(ReminderItem(title = "Electricity & WiFi Bill Payment", dateTimeStr = "Tomorrow at 9:00 AM", tag = "Bills", isActive = true))

                // Initial Budget Items
                dao.insertBudgetItem(BudgetItem(title = "Monthly Salary Deposit", amount = 3450.00, type = "INCOME", category = "Salary", dateStr = "Sep 1"))
                dao.insertBudgetItem(BudgetItem(title = "Freelance UI Design Project", amount = 650.00, type = "INCOME", category = "Freelance", dateStr = "Sep 4"))
                dao.insertBudgetItem(BudgetItem(title = "Supermarket Weekly Grocery", amount = 142.50, type = "EXPENSE", category = "Food & Dining", dateStr = "Sep 5"))
                dao.insertBudgetItem(BudgetItem(title = "High-speed Fiber Internet Bill", amount = 65.00, type = "EXPENSE", category = "Bills & Utilities", dateStr = "Sep 6"))
                dao.insertBudgetItem(BudgetItem(title = "New Running Shoes", amount = 89.99, type = "EXPENSE", category = "Shopping", dateStr = "Sep 7"))
            }
        }
    }
}
