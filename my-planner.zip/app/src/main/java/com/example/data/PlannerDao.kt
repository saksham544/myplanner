package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlannerDao {
    // --- Shopping Items ---
    @Query("SELECT * FROM shopping_items ORDER BY isBought ASC, createdAt DESC")
    fun getAllShoppingItems(): Flow<List<ShoppingItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingItem(item: ShoppingItem): Long

    @Update
    suspend fun updateShoppingItem(item: ShoppingItem)

    @Delete
    suspend fun deleteShoppingItem(item: ShoppingItem)

    @Query("DELETE FROM shopping_items WHERE isBought = 1")
    suspend fun clearBoughtShoppingItems()

    // --- To-Do Tasks ---
    @Query("SELECT * FROM todo_tasks ORDER BY isCompleted ASC, createdAt DESC")
    fun getAllTodoTasks(): Flow<List<TodoTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodoTask(task: TodoTask): Long

    @Update
    suspend fun updateTodoTask(task: TodoTask)

    @Delete
    suspend fun deleteTodoTask(task: TodoTask)

    @Query("DELETE FROM todo_tasks WHERE isCompleted = 1")
    suspend fun clearCompletedTasks()

    // --- Reminders ---
    @Query("SELECT * FROM reminders ORDER BY isActive DESC, createdAt DESC")
    fun getAllReminders(): Flow<List<ReminderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderItem): Long

    @Update
    suspend fun updateReminder(reminder: ReminderItem)

    @Delete
    suspend fun deleteReminder(reminder: ReminderItem)

    // --- Budget Items ---
    @Query("SELECT * FROM budget_items ORDER BY createdAt DESC")
    fun getAllBudgetItems(): Flow<List<BudgetItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudgetItem(item: BudgetItem): Long

    @Update
    suspend fun updateBudgetItem(item: BudgetItem)

    @Delete
    suspend fun deleteBudgetItem(item: BudgetItem)
}
