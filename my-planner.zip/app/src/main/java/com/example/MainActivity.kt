package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.PlannerDestination
import com.example.ui.PlannerViewModel
import com.example.ui.components.AddBudgetDialog
import com.example.ui.components.AddReminderDialog
import com.example.ui.components.AddShoppingDialog
import com.example.ui.components.AddTodoDialog
import com.example.ui.components.HeaderSearchField
import com.example.ui.components.PlannerThreeDContainer
import com.example.ui.components.PrivacyPolicyDialog
import com.example.ui.components.RateAppDialog
import com.example.ui.components.SearchResultsView
import com.example.ui.components.SpeedDialFab
import com.example.ui.screens.BudgetScreen
import com.example.ui.screens.RemindersScreen
import com.example.ui.screens.ShoppingListScreen
import com.example.ui.screens.SummaryScreen
import com.example.ui.screens.TodoListScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PlannerBlue

class MainActivity : ComponentActivity() {
    private val viewModel: PlannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = isDarkMode) {
                PlannerApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerApp(viewModel: PlannerViewModel) {
    val context = LocalContext.current

    val currentDestination by viewModel.currentDestination.collectAsStateWithLifecycle()
    val isDrawerOpen by viewModel.isDrawerOpen.collectAsStateWithLifecycle()
    val showPrivacyDialog by viewModel.showPrivacyDialog.collectAsStateWithLifecycle()
    val showRateDialog by viewModel.showRateDialog.collectAsStateWithLifecycle()
    val userRating by viewModel.userRating.collectAsStateWithLifecycle()

    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val isSearchActive by viewModel.isSearchActive.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val shoppingItems by viewModel.shoppingItems.collectAsStateWithLifecycle()
    val todoTasks by viewModel.todoTasks.collectAsStateWithLifecycle()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()
    val budgetItems by viewModel.budgetItems.collectAsStateWithLifecycle()

    // Local dialog visibility states for add items
    var showAddShoppingDialog by remember { mutableStateOf(false) }
    var showAddTodoDialog by remember { mutableStateOf(false) }
    var showAddReminderDialog by remember { mutableStateOf(false) }
    var showAddBudgetDialog by remember { mutableStateOf(false) }

    // Speed-dial state
    var isSpeedDialOpen by remember { mutableStateOf(false) }

    // Back navigation handling
    BackHandler(enabled = isDrawerOpen) {
        viewModel.closeDrawer()
    }
    BackHandler(enabled = isSpeedDialOpen) {
        isSpeedDialOpen = false
    }
    BackHandler(enabled = isSearchActive) {
        viewModel.setSearchActive(false)
    }

    PlannerThreeDContainer(
        isOpen = isDrawerOpen,
        currentDestination = currentDestination,
        onDestinationSelect = { destination ->
            viewModel.selectDestination(destination)
        },
        onCloseDrawer = { viewModel.closeDrawer() },
        onOpenDrawer = { viewModel.openDrawer() },
        onShareAppClick = {
            viewModel.closeDrawer()
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Organize your life with My Planner"
                )
                putExtra(
                    Intent.EXTRA_TEXT,
                    "I'm using My Planner to keep my Shopping List, To-Do tasks, Reminders, and Budget organized in one place! Highly recommended."
                )
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share My Planner via"))
        },
        onPrivacyPolicyClick = {
            viewModel.setPrivacyDialogVisible(true)
        },
        onRateAppClick = {
            viewModel.setRateDialogVisible(true)
        },
        isDarkMode = isDarkMode,
        onToggleTheme = { viewModel.toggleTheme() }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                if (isSearchActive) {
                    CenterAlignedTopAppBar(
                        title = {
                            HeaderSearchField(
                                query = searchQuery,
                                onQueryChange = { viewModel.setSearchQuery(it) },
                                onCloseSearch = { viewModel.setSearchActive(false) }
                            )
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                } else {
                    CenterAlignedTopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_app_logo),
                                    contentDescription = "My Planner Logo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, PlannerBlue.copy(alpha = 0.5f), CircleShape)
                                        .clickable { viewModel.openDrawer() }
                                        .testTag("top_bar_app_logo")
                                )
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(
                                        text = "My Planner",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 15.sp,
                                        color = PlannerBlue,
                                        lineHeight = 16.sp
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            currentDestination.iconEmoji,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(end = 4.dp)
                                        )
                                        Text(
                                            currentDestination.title,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = { viewModel.toggleDrawer() },
                                modifier = Modifier.testTag("menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Open navigation menu",
                                    tint = PlannerBlue
                                )
                            }
                        },
                        actions = {
                            // Top Header Search Button
                            IconButton(
                                onClick = { viewModel.setSearchActive(true) },
                                modifier = Modifier.testTag("top_bar_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search tasks, shopping, reminders",
                                    tint = PlannerBlue
                                )
                            }

                            // Theme Toggle Button
                            IconButton(
                                onClick = { viewModel.toggleTheme() },
                                modifier = Modifier.testTag("theme_toggle_button")
                            ) {
                                Text(
                                    text = if (isDarkMode) "🌙" else "☀️",
                                    fontSize = 18.sp
                                )
                            }

                            if (currentDestination != PlannerDestination.SUMMARY) {
                                IconButton(
                                    onClick = {
                                        when (currentDestination) {
                                            PlannerDestination.SHOPPING_LIST -> showAddShoppingDialog = true
                                            PlannerDestination.TODO_LIST -> showAddTodoDialog = true
                                            PlannerDestination.REMINDERS -> showAddReminderDialog = true
                                            PlannerDestination.BUDGET -> showAddBudgetDialog = true
                                            else -> {}
                                        }
                                    },
                                    modifier = Modifier.testTag("top_bar_add_action")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add new entry",
                                        tint = PlannerBlue
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isSearchActive) {
                    SearchResultsView(
                        query = searchQuery,
                        shoppingItems = shoppingItems,
                        todoTasks = todoTasks,
                        reminders = reminders,
                        onToggleShoppingItem = { viewModel.toggleShoppingItemBought(it) },
                        onToggleTodoTask = { viewModel.toggleTodoTaskCompleted(it) },
                        onToggleReminder = { viewModel.toggleReminderActive(it) },
                        onNavigateTo = { viewModel.selectDestination(it) },
                        onCloseSearch = { viewModel.setSearchActive(false) },
                        onQueryChange = { viewModel.setSearchQuery(it) }
                    )
                } else {
                    AnimatedContent(
                        targetState = currentDestination,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screenTransition"
                    ) { targetScreen ->
                        when (targetScreen) {
                            PlannerDestination.SHOPPING_LIST -> {
                                ShoppingListScreen(
                                    items = shoppingItems,
                                    onToggleBought = { viewModel.toggleShoppingItemBought(it) },
                                    onDeleteItem = { viewModel.deleteShoppingItem(it) },
                                    onClearBought = { viewModel.clearBoughtShoppingItems() },
                                    onAddNewClick = { showAddShoppingDialog = true }
                                )
                            }
                            PlannerDestination.TODO_LIST -> {
                                TodoListScreen(
                                    tasks = todoTasks,
                                    onToggleCompleted = { viewModel.toggleTodoTaskCompleted(it) },
                                    onDeleteTask = { viewModel.deleteTodoTask(it) },
                                    onClearCompleted = { viewModel.clearCompletedTasks() },
                                    onAddNewClick = { showAddTodoDialog = true }
                                )
                            }
                            PlannerDestination.REMINDERS -> {
                                RemindersScreen(
                                    reminders = reminders,
                                    onToggleActive = { viewModel.toggleReminderActive(it) },
                                    onDeleteReminder = { viewModel.deleteReminder(it) },
                                    onAddNewClick = { showAddReminderDialog = true }
                                )
                            }
                            PlannerDestination.BUDGET -> {
                                BudgetScreen(
                                    budgetItems = budgetItems,
                                    onDeleteItem = { viewModel.deleteBudgetItem(it) },
                                    onAddNewClick = { showAddBudgetDialog = true }
                                )
                            }
                            PlannerDestination.SUMMARY -> {
                                SummaryScreen(
                                    shoppingItems = shoppingItems,
                                    todoTasks = todoTasks,
                                    reminders = reminders,
                                    budgetItems = budgetItems,
                                    onNavigateTo = { viewModel.selectDestination(it) }
                                )
                            }
                        }
                    }

                    // Floating Action Button Speed Dial on Main Screen
                    if (!isDrawerOpen) {
                        SpeedDialFab(
                            isOpen = isSpeedDialOpen,
                            onToggle = { isSpeedDialOpen = !isSpeedDialOpen },
                            onDismiss = { isSpeedDialOpen = false },
                            onAddShopping = { showAddShoppingDialog = true },
                            onAddTodo = { showAddTodoDialog = true },
                            onAddReminder = { showAddReminderDialog = true }
                        )
                    }
                }
            }
        }
    }

    // Dialogs
    if (showAddShoppingDialog) {
        AddShoppingDialog(
            onDismiss = { showAddShoppingDialog = false },
            onConfirm = { title, quantity, category ->
                viewModel.addShoppingItem(title, quantity, category)
                showAddShoppingDialog = false
            }
        )
    }

    if (showAddTodoDialog) {
        AddTodoDialog(
            onDismiss = { showAddTodoDialog = false },
            onConfirm = { title, priority, category, dueDate ->
                viewModel.addTodoTask(title, priority, category, dueDate)
                showAddTodoDialog = false
            }
        )
    }

    if (showAddReminderDialog) {
        AddReminderDialog(
            onDismiss = { showAddReminderDialog = false },
            onConfirm = { title, dateTimeStr, tag ->
                viewModel.addReminder(title, dateTimeStr, tag)
                showAddReminderDialog = false
            }
        )
    }

    if (showAddBudgetDialog) {
        AddBudgetDialog(
            onDismiss = { showAddBudgetDialog = false },
            onConfirm = { title, amount, type, category, dateStr ->
                viewModel.addBudgetItem(title, amount, type, category, dateStr)
                showAddBudgetDialog = false
            }
        )
    }

    if (showPrivacyDialog) {
        PrivacyPolicyDialog(
            onDismiss = { viewModel.setPrivacyDialogVisible(false) }
        )
    }

    if (showRateDialog) {
        RateAppDialog(
            initialRating = userRating,
            onDismiss = { viewModel.setRateDialogVisible(false) },
            onSubmit = { rating ->
                viewModel.setRating(rating)
                Toast.makeText(context, "Thank you for rating My Planner $rating stars!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}
